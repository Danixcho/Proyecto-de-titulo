# Pendientes de la tesis que solo el autor puede resolver

Los textos marcados en rojo en el PDF (macro `\pendiente{...}`) son estos:

1. **Portada**: nombre del profesor guía del Proyecto de Título y mes de entrega.
2. **Declaración de autoría y de uso de IA**: ajustarla a la normativa vigente de la UNAB
   y describir con precisión en qué se usó la herramienta. Firmarla solo si es exacta.
3. **Anexo D**: dónde queda disponible el código (repositorio, GitHub o Zenodo) y con qué
   licencia.

Decisiones tomadas por defecto que conviene confirmar:

4. **Título**. Se reformuló como «Diseño y evaluación mediante simulación computacional de
   un módulo de software para la estimación de estados en la tolva de alimentación de un
   chancador primario, como componente de un gemelo digital conceptual». Si el título
   inscrito no puede cambiarse, hay que volver al inscrito y mantener en el texto la
   aclaración de alcance de la Sección 1.6.
5. **Anexo C, primer párrafo**: dice que varias afirmaciones corregidas se redactaron con
   apoyo de una herramienta de IA y no se detectaron en su momento. Es exacto; decidir si
   se mantiene esa frase tal cual.
6. **Formato institucional**: se usó el del informe del anteproyecto (carta, márgenes de
   2,5 cm, Times 12, interlineado 1,5, APA 7). Si el Proyecto de Título tiene otra pauta,
   ajustar el preámbulo de `main.tex`.
7. **Anexo D, sección «Historial»**: informa que el código se reconstruyó en octubre de
   2026, después de perderse el espacio de trabajo, y que reproduce los resultados. Es
   exacto; decidir si se mantiene.

Antes de la defensa:

8. **Lecturas**: de Simon (2006) y Bar-Shalom et al. (2001) solo se verificó el índice
   general (Anexo A). Conviene leer el capítulo 5 de Bar-Shalom (consistencia) y los
   capítulos 5 y 7 de Simon, y actualizar la columna «Lo leído» del Anexo A.
9. **Practicar** la deducción de la Sección 2.5.3 (ζ = 1/√2) en la pizarra.

Cómo actualizar números si se vuelve a ejecutar el estudio:

    cd estimacion_tolva
    python3 main.py && python3 tablas.py
    cp resultados/tablas_es/*.tex ../tesis/tablas/
    cp resultados/figuras_es/*.pdf ../tesis/figuras/
    cd ../tesis && latexmk -pdf main.tex
