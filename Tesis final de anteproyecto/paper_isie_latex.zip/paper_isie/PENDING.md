# Before submitting to IEEE ISIE 2027 (deadline 15 December 2026)

Checked on 29 September 2026 (recheck before submitting) at https://isie2027.ieee-ies.org/call-for-papers/call-for-papers/:
6 pages standard (up to 2 extra pages with a fee), official IEEE conference format,
English. The call does not say whether review is anonymous; check the author
instructions before uploading. The call does not mention a generative-AI policy, but
IEEE's submission policies require that the use of AI-generated content (text, figures,
images, code) be disclosed in the acknowledgments, identifying the system and the
sections involved. The Acknowledgment section has a placeholder for that disclosure.

Items only the authors can resolve (red text in the PDF):

1. Author list and affiliations. The previous version listed Omar I. Salinas Silva (UNAB)
   and Jorge I. Vásquez (UAI) as co-authors. Every co-author must read and approve this
   new version; do not submit with a name that has not approved it.
2. E-mail addresses (Daniel's institutional address was never confirmed).
3. Code availability statement (repository link or DOI) in Section IV.
4. AI-use disclosure in the Acknowledgment section.

Content decisions already taken (can be reverted):

- The paper reports simulation results only and says so in the abstract, Section I and
  Section VII. Do not add claims of plant validation.
- The module is described as a digital model of a component, not as a digital twin.
- Paper and thesis share results. If the thesis is published in a repository before the
  conference, check the conference policy on prior publication (a thesis is usually not
  considered prior publication, but confirm).

How to rebuild after re-running the study:

    cd estimacion_tolva && python3 main.py && python3 tablas.py
    cp resultados/tablas_en/*.tex ../paper_isie/tables/
    cp resultados/figuras_en/*.pdf ../paper_isie/figures/
    cd ../paper_isie && latexmk -pdf main.tex
